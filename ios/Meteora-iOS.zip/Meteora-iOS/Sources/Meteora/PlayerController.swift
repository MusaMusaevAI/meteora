import AppKit
import WebKit
import MeteoraCore

/// Playback surface shared by both engines: WebKit for WebM (see
/// WebPlayerController) and AVFoundation for everything macOS plays itself
/// (NativePlayerController). Views and the model talk only to this API.
@MainActor
class PlayerController: NSObject, ObservableObject {
    @Published var currentTime: Double = 0
    @Published var duration: Double = 0
    @Published var isPlaying = false
    @Published var rate: Double = 1
    @Published var volume: Double = 1
    @Published var videoSize: CGSize = .zero
    @Published var isReady = false
    @Published var mediaErrorCode = 0
    /// Short event log for diagnostics (self-test report).
    var diagnostics: [String] = []
    /// When the canvas path is unavailable we fall back to native snapshots.
    var usesSnapshotFallback = false
    var snapshotRetries = 0

    func log(_ s: String) {
        if diagnostics.count < 300 { diagnostics.append(s) }
    }

    func tearDown() {}
    func togglePlay() { isPlaying ? pause() : play() }
    func play() {}
    func pause() {}
    func seek(to t: Double) {}
    func skip(_ delta: Double) { seek(to: currentTime + delta) }
    func setRate(_ r: Double) { rate = r }
    func setVolume(_ v: Double) { volume = v }

    enum SampleError: Error, LocalizedError {
        case failed(String)
        var errorDescription: String? { if case .failed(let s) = self { return s }; return nil }
    }

    func waitUntilReady(timeout: Double = 30) async throws {
        let deadline = Date().addingTimeInterval(timeout)
        while !isReady {
            if mediaErrorCode != 0 { throw SampleError.failed("Видео не воспроизводится на этом Mac (код \(mediaErrorCode)).") }
            if Date() > deadline { throw SampleError.failed("Видео не загрузилось.") }
            try await Task.sleep(nanoseconds: 50_000_000)
        }
    }

    /// Small grayscale thumbnail of the frame at `t` (key-frame analysis).
    func sample(at t: Double) async throws -> FrameThumb { throw SampleError.failed("Не удалось получить кадр.") }
    func canDecode(codec: String, width: Int, height: Int) async -> Bool { false }
    func decodeSample(codec: String, width: Int, height: Int, chunks: [(Data, Bool, Double)]) async throws -> FrameThumb {
        throw SampleError.failed("Не удалось декодировать кадр.")
    }
    func grabDecoded() async throws -> CGImage? { nil }
    func releaseDecoded() {}
    /// Full-resolution image of the frame last sampled / currently shown.
    func grabFrame() async throws -> CGImage? { nil }
    func debugInfo() async -> String { "n/a" }

    static func thumb(from image: CGImage) -> FrameThumb? {
        let w = FrameThumb.width, h = FrameThumb.height
        var px = [UInt8](repeating: 0, count: w * h)
        let ok = px.withUnsafeMutableBytes { buf -> Bool in
            guard let ctx = CGContext(data: buf.baseAddress, width: w, height: h, bitsPerComponent: 8, bytesPerRow: w,
                                      space: CGColorSpaceCreateDeviceGray(), bitmapInfo: CGImageAlphaInfo.none.rawValue) else { return false }
            ctx.interpolationQuality = .high
            ctx.draw(image, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        return ok ? FrameThumb(luma: px) : nil
    }
}

/// Owns the WKWebView used to render WebM recordings and exposes a small,
/// typed API over it. All web content is local; the web view is configured
/// to be as inert as possible.
@MainActor
final class WebPlayerController: PlayerController {
    private var seenMessageTypes = Set<String>()
    private var crashCount = 0
    private var watchdogReloads = 0

    let webView: WKWebView
    private let world = WKContentWorld.world(name: "meteora")
    private var schemeHandler: MediaSchemeHandler?
    private let fileURL: URL?

    init(fileURL: URL?, audioOnly: Bool) {
        self.fileURL = fileURL
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .nonPersistent()
        config.suppressesIncrementalRendering = false
        config.mediaTypesRequiringUserActionForPlayback = []
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        config.preferences.isFraudulentWebsiteWarningEnabled = false
        config.preferences.isElementFullscreenEnabled = false
        config.defaultWebpagePreferences.allowsContentJavaScript = false // page JS off; our user script runs in its own world
        config.defaultWebpagePreferences.preferredContentMode = .desktop
        if #available(macOS 14.0, *) { config.allowsInlinePredictions = false }

        let handler = MediaSchemeHandler(fileURL: fileURL, audioOnly: audioOnly)
        var pendingLog: [String] = []
        handler.logger = { pendingLog.append($0) }
        config.setURLSchemeHandler(handler, forURLScheme: PlayerPage.scheme)

        let ucc = WKUserContentController()
        ucc.addUserScript(WKUserScript(source: PlayerPage.script, injectionTime: .atDocumentEnd,
                                       forMainFrameOnly: true, in: world))
        config.userContentController = ucc

        let wv = WKWebView(frame: .zero, configuration: config)
        wv.allowsMagnification = false
        wv.allowsBackForwardNavigationGestures = false
        wv.allowsLinkPreview = false
        wv.underPageBackgroundColor = .black
        if #available(macOS 13.3, *) { wv.isInspectable = false }
        webView = wv
        schemeHandler = handler
        super.init()

        ucc.add(WeakMessageHandler(self), contentWorld: world, name: "meteora")
        diagnostics = pendingLog
        handler.logger = { [weak self] s in self?.log(s) }
        webView.navigationDelegate = self
        webView.uiDelegate = self
        guard fileURL != nil else { return }
        Task { [weak self] in
            // Defence in depth on top of CSP and the navigation policy: the
            // content blocker refuses every load that is not our own scheme.
            let rules = #"[{"trigger":{"url-filter":".*"},"action":{"type":"block"}},"# +
                #"{"trigger":{"url-filter":"^meteora-media:"},"action":{"type":"ignore-previous-rules"}}]"#
            if let list = try? await WKContentRuleListStore.default()
                .compileContentRuleList(forIdentifier: "meteora-offline-v1", encodedContentRuleList: rules) {
                ucc.add(list)
                self?.log("rules:installed")
            } else {
                self?.log("rules:failed")
            }
            self?.webView.load(URLRequest(url: PlayerPage.pageURL))
        }
    }

    override func tearDown() {
        webView.stopLoading()
        webView.configuration.userContentController.removeAllScriptMessageHandlers()
        webView.navigationDelegate = nil
        webView.uiDelegate = nil
    }

    // MARK: Commands

    private func call(_ js: String, _ args: [String: Any] = [:]) {
        webView.callAsyncJavaScript(js + "; return 0", arguments: args, in: nil, in: world, completionHandler: nil)
    }

    /// Runs `body` (an async JS function body) in our isolated world.
    private func eval(_ body: String, _ args: [String: Any] = [:]) async throws -> Any? {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Any?, Error>) in
            webView.callAsyncJavaScript(body, arguments: args, in: nil, in: world) { result in
                switch result {
                case .success(let v): cont.resume(returning: v)
                case .failure(let e): cont.resume(throwing: e)
                }
            }
        }
    }

    override func play() { call("meteora.play()") }
    override func pause() { call("meteora.pause()") }
    override func seek(to t: Double) {
        let clamped = max(0, min(t, duration > 0 ? duration : t))
        currentTime = clamped
        call("meteora.seek(t)", ["t": clamped])
    }
    override func setRate(_ r: Double) { rate = r; call("meteora.rate(r)", ["r": r]) }
    override func setVolume(_ v: Double) { volume = v; call("meteora.volume(x)", ["x": v]) }

    // MARK: Frame sampling (used by key-frame analysis)

    override func sample(at t: Double) async throws -> FrameThumb {
        let result = try await eval("return await meteora.sample(t)", ["t": t])
        guard let dict = result as? [String: Any] else { throw SampleError.failed("Не удалось получить кадр.") }
        // btoa() maps each byte to one Latin-1 character, so base64-decoding
        // yields the raw luma bytes.
        if let b64 = dict["thumb"] as? String, let data = Data(base64Encoded: b64), let thumb = FrameThumb(luma: [UInt8](data)) {
            return thumb
        }
        if dict["tainted"] as? Bool == true {
            usesSnapshotFallback = true
            return try await stableSnapshotThumb()
        }
        throw SampleError.failed("Не удалось получить кадр.")
    }

    // MARK: WebCodecs decoding (preferred path for key-frame analysis)

    override func canDecode(codec: String, width: Int, height: Int) async -> Bool {
        let r = try? await eval("return await meteora.canDecode(c, w, h)", ["c": codec, "w": width, "h": height])
        return (r as? Bool) ?? ((r as? NSNumber)?.boolValue ?? false)
    }

    /// Decodes `chunks` (keyframe first) and returns a thumbnail of the last frame.
    override func decodeSample(codec: String, width: Int, height: Int, chunks: [(Data, Bool, Double)]) async throws -> FrameThumb {
        let payload: [[Any]] = chunks.map { [$0.0.base64EncodedString(), $0.1, Int(($0.2 * 1_000_000).rounded())] }
        let r = try await eval("return await meteora.decodeSample(c, w, h, chunks)",
                               ["c": codec, "w": width, "h": height, "chunks": payload])
        guard let d = r as? [String: Any], let b64 = d["thumb"] as? String, let data = Data(base64Encoded: b64),
              let thumb = FrameThumb(luma: [UInt8](data)) else {
            throw SampleError.failed("Не удалось декодировать кадр.")
        }
        return thumb
    }

    override func grabDecoded() async throws -> CGImage? {
        Self.image(fromDataURL: try await eval("return await meteora.grabDecoded()") as? String)
    }

    override func releaseDecoded() { call("meteora.releaseDecoded()") }

    static func image(fromDataURL s: String?) -> CGImage? {
        guard let s, s.hasPrefix("data:image/png;base64,"), let comma = s.firstIndex(of: ","),
              let data = Data(base64Encoded: String(s[s.index(after: comma)...])),
              data.count < 64 * 1024 * 1024,
              let src = CGImageSourceCreateWithData(data as CFData, [kCGImageSourceShouldCache: false] as CFDictionary),
              CGImageSourceGetCount(src) == 1 else { return nil }
        return CGImageSourceCreateImageAtIndex(src, 0, nil)
    }

    /// Full-resolution image of the frame currently shown.
    override func grabFrame() async throws -> CGImage? {
        if !usesSnapshotFallback, let img = Self.image(fromDataURL: try await eval("return await meteora.grab()") as? String) {
            return img
        }
        return try await snapshotVideo()
    }

    private var lastSnapshotThumb: FrameThumb?

    /// The compositor may still show the previous frame for a moment after a
    /// seek. Take small snapshots until the picture stops changing and has
    /// either changed from the previous sample or had time to (≈0.3 s).
    private func stableSnapshotThumb() async throws -> FrameThumb {
        let started = Date()
        var previous: FrameThumb?
        for _ in 0 ..< 12 {
            guard let img = try await snapshotVideo(pixelWidth: CGFloat(FrameThumb.width * 2)),
                  let thumb = Self.thumb(from: img) else { throw SampleError.failed("Не удалось снять кадр.") }
            if let p = previous, thumb.changedFraction(to: p) < 0.002 {
                let differsFromLast = lastSnapshotThumb.map { thumb.changedFraction(to: $0) > 0.002 } ?? true
                if differsFromLast || Date().timeIntervalSince(started) > 0.3 {
                    lastSnapshotThumb = thumb
                    return thumb
                }
            }
            previous = thumb
            snapshotRetries += 1
            try await Task.sleep(nanoseconds: 50_000_000)
        }
        lastSnapshotThumb = previous
        if let previous { return previous }
        throw SampleError.failed("Не удалось снять кадр.")
    }

    /// Native snapshot of just the video picture (without letterboxing),
    /// rendered at the video's own resolution (capped at 2560 px) so that
    /// small text on shared screens stays legible for OCR.
    private func snapshotVideo(pixelWidth: CGFloat? = nil) async throws -> CGImage? {
        let cfg = WKSnapshotConfiguration()
        cfg.afterScreenUpdates = true
        let bounds = webView.bounds
        if videoSize.width > 0, videoSize.height > 0, bounds.width > 0, bounds.height > 0 {
            let k = min(bounds.width / videoSize.width, bounds.height / videoSize.height)
            let w = videoSize.width * k, h = videoSize.height * k
            cfg.rect = CGRect(x: (bounds.width - w) / 2, y: (bounds.height - h) / 2, width: w, height: h)
            let scale = webView.window?.backingScaleFactor ?? 2
            let targetPixels = pixelWidth ?? min(videoSize.width, 2560)
            cfg.snapshotWidth = NSNumber(value: Double(targetPixels / scale))
        }
        let image = try await webView.takeSnapshot(configuration: cfg)
        var rect = CGRect(origin: .zero, size: image.size)
        return image.cgImage(forProposedRect: &rect, context: nil, hints: nil)
    }

    /// JS-side state for diagnostics.
    override func debugInfo() async -> String {
        let r = try? await eval("return JSON.stringify(meteora.info())")
        return (r as? String) ?? "unavailable"
    }

    // MARK: State updates from the page

    fileprivate func handle(_ body: Any) {
        guard let m = body as? [String: Any], let type = m["type"] as? String else { return }
        if seenMessageTypes.insert(type).inserted || type == "error" { log("js:\(type) rs=\(m["err"] ?? 0)") }
        func num(_ k: String) -> Double { (m[k] as? NSNumber)?.doubleValue ?? 0 }
        let t = num("t"), d = num("d")
        if t.isFinite { currentTime = t }
        if d.isFinite, d > 0 { duration = max(duration, d) }
        isPlaying = !(m["paused"] as? Bool ?? true)
        let w = num("w"), h = num("h")
        if w > 0, h > 0, w <= 16384, h <= 16384 { videoSize = CGSize(width: w, height: h) }
        let err = Int(num("err"))
        if err != 0 { mediaErrorCode = err }
        if ["loadeddata", "canplay", "playing", "seeked"].contains(type) { isReady = true }
        if type == "ended" { isPlaying = false }
    }
}

extension WebPlayerController: WKNavigationDelegate, WKUIDelegate {
    /// Only our own page may ever be loaded in this web view.
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction) async -> WKNavigationActionPolicy {
        let ok = action.request.url == PlayerPage.pageURL && action.targetFrame?.isMainFrame == true
        return ok ? .allow : .cancel
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        nil
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        log("nav:finish")
        // Watchdog: now and then WebKit leaves the <video> without a source
        // (networkState 3, no request reaches our scheme). Reload the page
        // up to twice if nothing has loaded after a while.
        let attempt = watchdogReloads
        Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: 12_000_000_000)
            guard let self, !self.isReady, self.mediaErrorCode == 0, self.watchdogReloads == attempt,
                  self.watchdogReloads < 2, self.fileURL != nil else { return }
            self.watchdogReloads += 1
            self.log("watchdog:reload \(self.watchdogReloads)")
            self.webView.load(URLRequest(url: PlayerPage.pageURL))
        }
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { log("nav:fail \(error)") }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        log("nav:failProvisional \(error)")
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        log("webcontent:terminated")
        isReady = false
        // Recover from a crashed renderer at most twice, then give up with an
        // error instead of looping on a file that keeps crashing it.
        crashCount += 1
        if crashCount <= 2, fileURL != nil {
            webView.load(URLRequest(url: PlayerPage.pageURL))
        } else {
            mediaErrorCode = -1
        }
    }
}

/// Breaks the retain cycle WKUserContentController → handler → controller.
private final class WeakMessageHandler: NSObject, WKScriptMessageHandler {
    weak var target: WebPlayerController?
    init(_ target: WebPlayerController) { self.target = target }

    func userContentController(_ ucc: WKUserContentController, didReceive message: WKScriptMessage) {
        // Accept messages only from our own page in the main frame.
        guard message.frameInfo.isMainFrame,
              message.frameInfo.securityOrigin.protocol == PlayerPage.scheme,
              message.frameInfo.securityOrigin.host == PlayerPage.host else { return }
        let body = message.body
        MainActor.assumeIsolated { target?.handle(body) }
    }
}
